import java.util.Scanner;
class record
{
    double m1,m2,m3,m4,m5 ,percent;
    char grade;
    
    void input() {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter marks in 5 subjects ");
        m1 = s.nextDouble();
        m2 = s.nextDouble();
        m3 = s.nextDouble();
        m4 = s.nextDouble();
        m5 = s.nextDouble();

    }
    
    void alpha()
    {
        input();
        percent = (m1+m2+m3+m4+m5)/5;
        if(percent>=90.00)
            grade = 'A';
        else 
            if (percent>=70.00 && percent<90.00)
            grade = 'B';  
        else 
            if (percent>=50.00 && percent<70.00)
            grade = 'C';     
        else
            if (percent>=40.00 && percent<50.00)
            grade = 'D';
        else
            grade = 'F';
    }
    
    void display()
    {
     alpha();
     System.out.println("Percentage : "+percent);
     System.out.println(" Grade : "+grade);
    
    }
}

public class Student
{
    public static void main(String args[])
    {
        record r = new record();
        r.display();
    }
}


import java.util.Scanner;
class details {
    String name;
    int date,month,year,age;
    double m_sal,t_sal,tax;
    
    void input () {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter name : ");
        name = s.next();
        System.out.print("Enter date of birth : ");
        date = s.nextInt();
        System.out.print("Enter month of birth : ");
        month = s.nextInt();
        System.out.print("Enter year of birth : ");
        year = s.nextInt();
        System.out.print("Enter monthly salary : ");
        m_sal = s.nextDouble();
    }
    
    void cal_tax() {
        input();
        t_sal = 12 * m_sal;
        if(t_sal>=500000)
            tax = 0.2 * t_sal;
        else 
            if (t_sal>=400000 && t_sal<500000)
            tax = 0.15 * t_sal;  
        else 
            if (t_sal>=300000 && t_sal<400000)
            tax = 0.1* t_sal;     
        else
            if (t_sal>=200000 && t_sal<300000)
            tax = 0.05 * t_sal;
        else
            tax = 0;
    }
    
    void cal_age() {
      age = 2020 - year;
      if (month > 10)
          age = age - 1;
      else if (month == 10) {
          if(date > 10)
              age = age - 1;
      }
    }
    
    void display()    {
     cal_tax();
     cal_age();
     System.out.println("\nName : "+name);
     System.out.println("Age : "+age);
     System.out.println("Annual salary : "+t_sal);
     System.out.println("Tax : "+tax);
   }

}

public class Employee {
    public static void main(String args[])
    {
        details d = new details();
        d.display();
    }
}

import java.util.Scanner;
public class Sum {
    public static void main(String args[]) {
        Scanner s = new Scanner(System.in);
        int[] arr = new int[5];
        int sum = 0;
        for(int i=0;i<5;i++) {
            System.out.print("Enter no. " + (i+1) +" : ");
            arr[i] = s.nextInt();
            sum += arr[i];
        }
        System.out.println("Sum = " +sum);
    }
}
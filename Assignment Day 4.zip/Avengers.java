import java.util.Scanner;
public class Avengers{
    
    String name,power,weapon,planet;
    int age;
    
    void getDetails() {
        Scanner s = new Scanner(System.in);
        System.out.print("\nEnter name of Avenger : ");
        name = s.next();
        System.out.print("Enter the age of Avenger : ");
        age = s.nextInt();
        System.out.print("Enter the power of Avenger : ");
        power = s.next();
        System.out.print("Enter the weapon of Avenger : ");
        weapon = s.next();
        System.out.print("Enter the planet of Avenger : ");
        planet = s.next();
    }
    
    void displayDetails() {
        System.out.println("\nName of Avenger : "+name);
        System.out.println("Age of Avenger : "+age);
        System.out.println("Power of Avenger : "+power);
        System.out.println("Weapon of Avenger : "+weapon);
        System.out.println("Planet of Avenger : "+planet);
    } 
    
    public static void main(String args[]) {
       
        Avengers[] a = new Avengers[5];
        for(int i=0;i<5;i++) {
            System.out.println("\nEnter details of Avenger no. " + (i+1) +" : ");
            a[i] = new Avengers();
            a[i].getDetails();
        }
        System.out.println("\nDetails of Avengers are : ");
        for(int i=0;i<5;i++) 
            a[i].displayDetails();
    }
}
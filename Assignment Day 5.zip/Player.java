/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Quiz;

/**
 *
 * @author Pranay Singhal
 */
import java.util.Scanner;
public class Player {
    Scanner s = new Scanner(System.in);
    String name;
    int score=0,age;

    public void getDetails(){
        System.out.print("Enter player's name : ");
        name=s.next();
        System.out.print("Enter player's age : ");
        age=s.nextInt();
    }

}

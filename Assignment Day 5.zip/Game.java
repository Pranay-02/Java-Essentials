/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Quiz;

/**
 *
 * @author Pranay Singhal
 */
public class Game {
    Question[] questions=new Question[4];
    Player player=new Player();

    String[] questionsdata={
        "Which team has won the maximum no. of IPL trophies?",
        "Who has scored the most runs in IPL history?",
        "Which is the only team to retained the IPL?",
        "Which player has hit the most no. of sixes in the IPL?"    
    };
    
    String[] options1={"CSK","Suresh Raina","KKR","David Warner"};
    String[] options2={"MI","Virat Kholi","SRH","MS Dhoni"};
    String[] options3={"RCB","David Warner","MI","Rohit Sharma"};
    String[] options4={"KKR","Rohit Sharma","CSK","Chris Gayle"};
    int[] answers={2,2,4,4};


    public void initGame()
    {
        for(int i=0;i<4;i++)
            questions[i]=new Question();
      
        for(int i=0;i<4;i++)
        {
            questions[i].question=questionsdata[i];
            questions[i].option1=options1[i];
            questions[i].option2=options2[i];
            questions[i].option3=options3[i];
            questions[i].option4=options4[i];
            questions[i].correctAnswer=answers[i];
        }

    }
    public void play()
    {

          player.getDetails();
          for(int i=0;i<4;i++)
          {
              int status=questions[i].askQuestion();
              player.score +=status;
              if(status==1)
                  System.out.println("Correct Answer!!");
              else
                  System.out.println("Wrong option");
          }
        System.out.println(player.name+" your score is "+player.score);
    }
}

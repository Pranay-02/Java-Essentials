/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package second;

/**
 *
 * @author Pranay Singhal
 */
public class Engineer extends Employee {
        private String branch;
    
        @Override
    void inputDetails() {
        System.out.println("\nEnter details of a Engineer");
        getDetails();
        System.out.print("Enter your Branch : ");
        s.next();
    }
    
        @Override
    void printDetails() {
        displayDetails();
        System.out.println("Branch : "+branch);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package second;

/**
 *
 * @author Pranay Singhal
 */
public class Pilot extends Employee {
        private String plane_no;
    
        @Override
    void inputDetails() {
        System.out.println("\nEnter details of a Pilot");
        getDetails();
        System.out.print("Enter your plane number : ");
        s.next();
    }
    
        @Override
    void printDetails() {
        displayDetails();
        System.out.println("Plane number : "+plane_no);
    }
}

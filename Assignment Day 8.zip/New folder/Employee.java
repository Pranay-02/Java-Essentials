/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package second;

/**
 *
 * @author Pranay Singhal
 */
import java.util.Scanner;

public class Employee {
    private String name , designation;
    private int age , salary;
    Scanner s = new Scanner(System.in);    
    public void displayDetails() {
        System.out.println("Name : "+name);
        System.out.println("Age : "+age);
        System.out.println("Salary : "+salary);
        System.out.println("Designation : "+designation);
    }
    
    public void getDetails() {
        System.out.print("\nEnter the name : ");
        name = s.next();
        System.out.print("Enter the age : ");
        age = s.nextInt();
        System.out.print("Enter the salary : ");
        salary = s.nextInt();
        System.out.print("Enter the designation : ");
        designation = s.next();
    }

    void inputDetails() {}

    void printDetails() {}
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package second;

/**
 *
 * @author Pranay Singhal
 */
public class Doctor extends Employee{
    private String specialty;
    
    @Override
    void inputDetails() {
        System.out.println("\nEnter details of a Doctor");
        getDetails();
        System.out.print("Enter your Specialty : ");
        s.next();
    }
    
    @Override
    void printDetails() {
        displayDetails();
        System.out.println("Specialty : "+specialty);
    }
    
}

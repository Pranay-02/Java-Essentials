/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package second;

import java.util.ArrayList;

/**
 *
 * @author Pranay Singhal
 */
public class Main {
    public static void main(String args[]) { 
    Employee[] e = new Employee[3];
    e[0] = new Doctor();
    e[1] = new Engineer();
    e[2] = new Pilot();
    for(int i=0;i<3;i++) 
        e[i].inputDetails();
    for(int i=0;i<3;i++) 
        e[i].printDetails();
    }
}


